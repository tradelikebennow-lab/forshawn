#!/usr/bin/env python3
"""
TX Terminal v2 - Methodology Screener: Universe Engine
=======================================================
Builds the dynamic stock universe for the Qullamaggie / Minervini screens.

Phase 1 (this file): assemble a gated list of <=500 liquid US >=$1B-mcap
tickers from Yahoo's custom screener, written to data/tx-screener-universe.js.

Runs WEEKLY (not nightly) - universe membership is stable; nightly metric
computation (Phase 2) runs against whatever membership this produced.

Data source: Yahoo Finance custom screener (POST), per project canon.
No API key, no paid dependency.
"""

import sys
import os
import time
import json
from datetime import datetime, timezone, timedelta
import requests

# Browser UA - Yahoo blocks non-browser agents (project canon, matches movers/v1)
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)

# Yahoo endpoints
COOKIE_URL = "https://fc.yahoo.com"
CRUMB_URL = "https://query2.finance.yahoo.com/v1/test/getcrumb"
SCREENER_URL = "https://query2.finance.yahoo.com/v1/finance/screener"
# v8 chart endpoint (query1) - same path v1 + movers use successfully.
CHART_URL = "https://query1.finance.yahoo.com/v8/finance/chart/{sym}"

# Universe filter (verified live): US equities, market cap >= $1B,
# sorted by daily volume descending so the most liquid names come first.
MCAP_FLOOR = 1_000_000_000

# Output cache: ../data relative to this scripts/ dir (matches movers layout).
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CACHE_PATH = os.path.normpath(
    os.path.join(_SCRIPT_DIR, "..", "data", "tx-screener-universe.js")
)
GMT8 = timezone(timedelta(hours=8))   # project canon: GMT+8, no DST
MIN_VALID_COUNT = 250                  # below this, keep last good (D1-06)


def get_yahoo_session():
    """
    Perform the Yahoo 'handshake': obtain a session cookie, then a crumb token.

    The custom screener POST endpoint requires a valid crumb tied to the
    session's cookie. This is NOT a login or paid key - it is an anti-CSRF
    token Yahoo hands to any browser-like client.

    Returns:
        (requests.Session, str): an authenticated session and its fresh crumb.

    Raises:
        RuntimeError: if the handshake fails (no crumb, HTTP error, or an
                      HTML error page returned instead of a token). Caller
                      should fall back to the predefined-screener path or
                      keep the last good universe.
    """
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT})

    # Step 1: cookie. fc.yahoo.com commonly returns 404 but still sets the
    # cookie we need - so we deliberately ignore the status code here and only
    # care that a cookie landed in the jar.
    try:
        session.get(COOKIE_URL, timeout=10)
    except requests.RequestException as exc:
        raise RuntimeError(f"cookie request failed: {exc}") from exc

    if len(session.cookies) == 0:
        raise RuntimeError("crumb handshake failed: no cookie was set")

    # Step 2: crumb token, fetched fresh every run (never hardcoded).
    try:
        resp = session.get(CRUMB_URL, timeout=10)
    except requests.RequestException as exc:
        raise RuntimeError(f"crumb request failed: {exc}") from exc

    crumb = resp.text.strip()

    # A valid crumb is a short alphanumeric token. An HTML page ("<...")
    # or empty body means Yahoo refused us (rate-limited / blocked IP).
    if resp.status_code != 200 or not crumb or "<" in crumb:
        raise RuntimeError(
            f"crumb handshake failed: status={resp.status_code} "
            f"body={crumb[:60]!r}"
        )

    return session, crumb


def _build_payload(offset, page_size):
    """Construct the verified custom-screener POST body for one page."""
    return {
        "size": page_size,
        "offset": offset,
        "sortField": "dayvolume",
        "sortType": "DESC",
        "quoteType": "EQUITY",
        "query": {
            "operator": "AND",
            "operands": [
                {"operator": "gte",
                 "operands": ["intradaymarketcap", MCAP_FLOOR]},
                {"operator": "eq", "operands": ["region", "us"]},
            ],
        },
        "userId": "",
        "userIdType": "guid",
    }


def _fetch_page(session, crumb, offset, page_size):
    """
    POST one screener page. Returns the list of quote dicts, or None on
    failure (so the caller can decide whether to retry / stop).
    """
    try:
        resp = session.post(
            SCREENER_URL,
            params={"crumb": crumb, "lang": "en-US", "region": "US"},
            json=_build_payload(offset, page_size),
            timeout=15,
        )
    except requests.RequestException:
        return None
    if resp.status_code != 200:
        return None
    try:
        result = resp.json()["finance"]["result"]
    except (ValueError, KeyError, TypeError):
        return None
    if not result:
        return None
    return result[0].get("quotes", [])


def fetch_universe(session, crumb, target=500, page_size=100):
    """
    Page through the custom screener to assemble up to `target` tickers,
    most-liquid first. Dedups by symbol (offset pagination shouldn't overlap,
    but we guard anyway).

    Each retained row keeps only the fields later phases need. `sector` is
    frequently absent from screener rows -> stored as None, NEVER 0 (avoids
    the `v or 0` masking trap from project canon).

    A page that fails is retried ONCE; a second failure stops paging and we
    return whatever has been collected so far (partial-result tolerance).

    Returns:
        list[dict]: rows with symbol, marketCap, regularMarketPrice,
                    regularMarketVolume, sector.
    """
    collected = []
    seen = set()
    offset = 0

    while len(collected) < target:
        quotes = _fetch_page(session, crumb, offset, page_size)
        if quotes is None:
            # one retry for this page
            quotes = _fetch_page(session, crumb, offset, page_size)
        if quotes is None:
            print(f"  [warn] page at offset {offset} failed twice - "
                  f"stopping with {len(collected)} collected")
            break
        if not quotes:
            # empty page = no more results in the universe
            break

        for q in quotes:
            sym = q.get("symbol")
            if not sym or sym in seen:
                continue
            mcap = q.get("marketCap")
            if mcap is None or mcap < MCAP_FLOOR:
                continue
            seen.add(sym)
            collected.append({
                "symbol": sym,
                "marketCap": mcap,
                "regularMarketPrice": q.get("regularMarketPrice"),
                "regularMarketVolume": q.get("regularMarketVolume"),
                "sector": q.get("sector"),  # None if absent - not 0
            })
            if len(collected) >= target:
                break

        offset += page_size

    return collected[:target]


def apply_gates(rows, min_dollar_vol=10_000_000):
    """
    Liquidity/quality gates beyond the mcap floor (D1-03).

    Keeps a row only if:
      - marketCap >= $1B (re-checked defensively), AND
      - avg dollar volume proxy (price x volume) >= $10M/day

    Rows missing price or volume are dropped (can't judge liquidity).
    The >=250-trading-days HISTORY gate is intentionally NOT here - it needs
    real OHLCV and is applied in Task 4, where the chart endpoint is hit.

    Every drop is logged with a reason. Returns survivors.
    """
    survivors = []
    dropped = {"no_price": 0, "no_volume": 0, "low_mcap": 0, "low_dollar_vol": 0}

    for r in rows:
        mcap = r.get("marketCap")
        price = r.get("regularMarketPrice")
        vol = r.get("regularMarketVolume")

        if mcap is None or mcap < MCAP_FLOOR:
            dropped["low_mcap"] += 1
            continue
        if price is None:
            dropped["no_price"] += 1
            continue
        if vol is None:
            dropped["no_volume"] += 1
            continue

        dollar_vol = price * vol
        if dollar_vol < min_dollar_vol:
            dropped["low_dollar_vol"] += 1
            continue

        r["dollar_vol"] = dollar_vol  # cache it for later sort/display
        survivors.append(r)

    total_dropped = sum(dropped.values())
    print(f"  gates: {len(rows)} in -> {len(survivors)} kept, "
          f"{total_dropped} dropped {dropped}")
    return survivors


def _count_history_days(session, sym):
    """
    Fetch ~2y daily candles for one symbol and count non-null closes.
    Returns the count, or None if the request fails / response is malformed.

    Filtering None out of the close array before counting matches project
    canon (Yahoo can interleave nulls for halted/no-trade days).
    """
    try:
        resp = session.get(
            CHART_URL.format(sym=sym),
            params={"range": "2y", "interval": "1d"},
            timeout=15,
        )
    except requests.RequestException:
        return None
    if resp.status_code != 200:
        return None
    try:
        result = resp.json()["chart"]["result"]
        if not result:
            return None
        closes = result[0]["indicators"]["quote"][0]["close"]
    except (ValueError, KeyError, TypeError, IndexError):
        return None
    return sum(1 for c in closes if c is not None)


def validate_history(session, rows, min_days=250, cap=500, throttle=0.1,
                     limit=None):
    """
    History gate (D1-03): drop any ticker with < `min_days` of daily closes,
    so Phase 2's SMA200 / 52-week math never breaks on recent IPOs.

    COST: one chart call per ticker, sequential. ~500 calls ~= 60-90s. This
    is the expensive step - but the universe runs WEEKLY (D1-04), not nightly,
    so the cost is amortised. Throttled to be polite to Yahoo.

    Each ticker gets ONE retry on failure; a second failure drops it (logged).
    After validation, survivors are hard-capped to `cap` (they arrive already
    volume-sorted from fetch_universe, so the cap keeps the most liquid).

    `limit` is a TEST-ONLY knob to validate a subset without 500 live calls.
    """
    work = rows[:limit] if limit else rows
    survivors = []
    dropped_short = 0
    dropped_fail = 0
    t0 = time.time()

    for i, r in enumerate(work, 1):
        sym = r["symbol"]
        days = _count_history_days(session, sym)
        if days is None:
            days = _count_history_days(session, sym)  # one retry
        if days is None:
            dropped_fail += 1
            print(f"  [drop:fetch-fail] {sym}")
        elif days < min_days:
            dropped_short += 1
            print(f"  [drop:short-history] {sym} ({days}d < {min_days})")
        else:
            r["history_days"] = days
            survivors.append(r)
        if throttle:
            time.sleep(throttle)

    elapsed = time.time() - t0
    print(f"  history: {len(work)} checked in {elapsed:.1f}s -> "
          f"{len(survivors)} valid, {dropped_short} short, "
          f"{dropped_fail} fetch-fail")
    return survivors[:cap]


def write_cache(rows, path=CACHE_PATH):
    """
    Write the universe to a .js cache the terminal loads via <script> (matches
    movers' window.* wrapper format, not bare JSON).

    D1-06 floor: if the run produced < MIN_VALID_COUNT names, treat it as a
    failed run - DO NOT overwrite the existing good file. Log and return False.

    `sector` is intentionally omitted: Yahoo's screener returns it null for
    every row, so it would be dead weight. (Deferred Phase 4 idea: backfill
    via a second per-ticker call if sector is ever wanted in the UI.)

    Returns True if written, False if skipped.
    """
    if len(rows) < MIN_VALID_COUNT:
        print(f"  [skip-write] only {len(rows)} names (< {MIN_VALID_COUNT}) - "
              f"keeping last good universe, not overwriting")
        return False

    payload = {
        "generated": datetime.now(GMT8).isoformat(timespec="seconds"),
        "count": len(rows),
        "tickers": [
            {
                "symbol": r["symbol"],
                "mcap": r["marketCap"],
                "dollar_vol": r.get("dollar_vol"),
                "history_days": r.get("history_days"),
            }
            for r in rows
        ],
    }

    os.makedirs(os.path.dirname(path), exist_ok=True)
    body = "window.SCREENER_UNIVERSE = " + json.dumps(payload, indent=2) + ";\n"
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(body)
    print(f"  [wrote] {len(rows)} names -> {path}")
    return True


def _dry_history(limit=30):
    """--dry-history[=N]: full funnel through history validation on a subset."""
    try:
        session, crumb = get_yahoo_session()
    except RuntimeError as exc:
        print(f"[FAIL] {exc}")
        return 1
    rows = fetch_universe(session, crumb)
    gated = apply_gates(rows)
    print(f"[OK] {len(gated)} gated; validating history on first {limit}...")
    valid = validate_history(session, gated, limit=limit)
    print(f"[OK] {len(valid)} passed history gate")
    return 0


def _dry_gate():
    """--dry-gate: handshake + fetch + gate, print the funnel."""
    try:
        session, crumb = get_yahoo_session()
    except RuntimeError as exc:
        print(f"[FAIL] {exc}")
        return 1
    rows = fetch_universe(session, crumb)
    print(f"[OK] fetched {len(rows)}")
    gated = apply_gates(rows)
    print(f"[OK] {len(gated)} survived liquidity gates")
    for r in gated[:10]:
        print(f"  {r['symbol']:6} | ${r['marketCap']/1e9:8.1f}B | "
              f"$vol ${r['dollar_vol']/1e6:8.1f}M")
    return 0


def _dry_fetch():
    """--dry-fetch: run handshake + fetch only, print the count and a sample."""
    try:
        session, crumb = get_yahoo_session()
    except RuntimeError as exc:
        print(f"[FAIL] {exc}")
        return 1
    rows = fetch_universe(session, crumb)
    print(f"[OK] fetched {len(rows)} tickers (mcap >= $1B, US equity)")
    for r in rows[:10]:
        mc = r["marketCap"] / 1e9
        print(f"  {r['symbol']:6} | ${mc:8.1f}B | px {r['regularMarketPrice']}")
    return 0


def run_full(dry_run=False):
    """
    Full pipeline: handshake -> fetch -> gate -> history-validate -> write.

    Wires Tasks 1-5 with a stage-by-stage funnel log. On --dry-run, runs the
    whole thing but stops before writing (prints what WOULD be written).

    Returns process exit code: 0 on success (incl. a logged skip-write),
    1 only on unrecoverable failure (dead handshake).
    """
    stamp = datetime.now(GMT8).isoformat(timespec="seconds")
    print(f"=== TX screener universe build @ {stamp} "
          f"({'DRY' if dry_run else 'LIVE'}) ===")

    try:
        session, crumb = get_yahoo_session()
    except RuntimeError as exc:
        print(f"[FATAL] handshake failed: {exc}")
        print("        (fallback: keep last good universe; investigate IP/"
              "rate-limit if persistent)")
        return 1

    rows = fetch_universe(session, crumb)
    print(f"[stage] fetched: {len(rows)}")

    gated = apply_gates(rows)
    print(f"[stage] liquidity-gated: {len(gated)}")

    valid = validate_history(session, gated)
    print(f"[stage] history-valid + capped: {len(valid)}")

    if dry_run:
        print(f"[DRY] would write {len(valid)} names "
              f"({'PASS' if len(valid) >= MIN_VALID_COUNT else 'BELOW FLOOR'})")
        return 0

    write_cache(valid)
    print("=== done ===")
    return 0


def _test_session():
    """--test-session: prove the handshake works, print the crumb, exit 0/1."""
    try:
        _, crumb = get_yahoo_session()
    except RuntimeError as exc:
        print(f"[FAIL] {exc}")
        return 1
    print(f"[OK] crumb handshake succeeded | crumb={crumb!r}")
    return 0


if __name__ == "__main__":
    if "--test-session" in sys.argv:
        sys.exit(_test_session())
    if "--dry-fetch" in sys.argv:
        sys.exit(_dry_fetch())
    if "--dry-gate" in sys.argv:
        sys.exit(_dry_gate())
    hist_flag = [a for a in sys.argv if a.startswith("--dry-history")]
    if hist_flag:
        n = 30
        if "=" in hist_flag[0]:
            try:
                n = int(hist_flag[0].split("=", 1)[1])
            except ValueError:
                pass
        sys.exit(_dry_history(limit=n))
    if "--dry-run" in sys.argv:
        sys.exit(run_full(dry_run=True))
    # Default: full live run (handshake -> fetch -> gate -> history -> write).
    try:
        sys.exit(run_full(dry_run=False))
    except Exception as exc:  # last-resort guard - never crash the scheduler
        print(f"[FATAL] unrecoverable: {exc}")
        sys.exit(1)
