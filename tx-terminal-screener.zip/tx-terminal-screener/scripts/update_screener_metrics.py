#!/usr/bin/env python3
"""
TX Terminal v2 - Methodology Screener: Metrics Computation (Phase 2)
====================================================================
For every ticker in the Phase 1 universe cache, fetch 2y daily OHLCV and
compute the raw metrics the Phase 3 screen filters (Qullamaggie / Minervini)
will consume:

  - MA stack        : EMA10, SMA20/50/100/200 (+ full EMA/SMA set for reuse)
  - SMA200 slope    : is the 200-day SMA rising (~1 month lookback)
  - 52-week hi/lo   : max/min close over the last ~252 sessions
  - 20-day range    : where the last close sits in its 20-day high-low band
  - green candle    : last closed bar up vs prior close AND up vs its own open
  - returns         : 1W / 1M / 3M / 6M price change
  - RS percentiles  : each return percentile-ranked WITHIN this universe

Runs NIGHTLY against whatever membership update_screener_universe.py produced.
Output cache: data/tx-screener-metrics.js  (window.SCREENER_METRICS = {...}).

Mirrors update_screener_universe.py: same Yahoo handshake, same .js wrapper,
same GMT+8 stamp, same D1-06 "keep last good on short run" floor, same CLI
funnel-log style. No new dependency beyond pandas (already in the v2 venv).
"""

import sys
import os
import time
import json
from datetime import datetime, timezone, timedelta

import requests
import pandas as pd

# Browser UA - Yahoo blocks non-browser agents (project canon, matches Phase 1).
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)

# Yahoo endpoints (identical to Phase 1).
COOKIE_URL = "https://fc.yahoo.com"
CRUMB_URL = "https://query2.finance.yahoo.com/v1/test/getcrumb"
CHART_URL = "https://query1.finance.yahoo.com/v8/finance/chart/{sym}"

# Paths: this file lives in scripts/, caches live in ../data/ (Phase 1 layout).
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
UNIVERSE_CACHE_PATH = os.path.normpath(
    os.path.join(_SCRIPT_DIR, "..", "data", "tx-screener-universe.js")
)
METRICS_CACHE_PATH = os.path.normpath(
    os.path.join(_SCRIPT_DIR, "..", "data", "tx-screener-metrics.js")
)

GMT8 = timezone(timedelta(hours=8))   # project canon: GMT+8, no DST
MIN_VALID_COUNT = 250                 # below this, keep last good (mirrors D1-06)
MIN_ROWS = 250                        # need >=250 closes for SMA200 / 52w math

# Lookbacks in trading days. ~21/mo, ~63/qtr, ~126/half, ~252/yr.
RET_LOOKBACKS = {"1w": 5, "1m": 21, "3m": 63, "6m": 126}
SLOPE_LOOKBACK = 22                   # ~1 month, for "is SMA200 rising"
WIN_52W = 252
WIN_20D = 20
ATR_WIN = 14


# --------------------------------------------------------------------------- #
# Session (handshake copied verbatim from Phase 1 - proven from this IP).
# --------------------------------------------------------------------------- #
def get_yahoo_session():
    """
    Obtain a Yahoo session cookie + crumb. Identical handshake to Phase 1's
    update_screener_universe.py (verified working from the user's IP).

    Returns (requests.Session, str). Raises RuntimeError on failure so the
    caller can keep the last-good metrics file rather than overwrite it.
    """
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT})

    # Step 1: cookie. fc.yahoo.com often 404s but still sets the cookie - we
    # only care that a cookie landed in the jar, not the status code.
    try:
        session.get(COOKIE_URL, timeout=10)
    except requests.RequestException as exc:
        raise RuntimeError(f"cookie request failed: {exc}") from exc

    if len(session.cookies) == 0:
        raise RuntimeError("crumb handshake failed: no cookie was set")

    # Step 2: crumb, fetched fresh every run (never hardcoded).
    try:
        resp = session.get(CRUMB_URL, timeout=10)
    except requests.RequestException as exc:
        raise RuntimeError(f"crumb request failed: {exc}") from exc

    crumb = resp.text.strip()
    if resp.status_code != 200 or not crumb or "<" in crumb:
        raise RuntimeError(
            f"crumb handshake failed: status={resp.status_code} "
            f"body={crumb[:60]!r}"
        )
    return session, crumb


# --------------------------------------------------------------------------- #
# Task 1: load the Phase 1 universe cache.
# --------------------------------------------------------------------------- #
def load_universe(path=UNIVERSE_CACHE_PATH):
    """
    Read the Phase 1 universe cache and return its ticker list.

    The file is a JS wrapper, not bare JSON:
        window.SCREENER_UNIVERSE = { ...json... };
    so we strip the assignment prefix and the trailing semicolon, then
    json.loads the middle.

    Returns list[dict] (each has at least 'symbol'). Raises RuntimeError if
    the file is missing or unparseable - without a universe there is nothing
    to compute, and we must NOT silently write an empty metrics file.
    """
    if not os.path.exists(path):
        raise RuntimeError(f"universe cache not found at {path} "
                           f"(run update_screener_universe.py first)")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            text = fh.read()
    except OSError as exc:
        raise RuntimeError(f"could not read universe cache: {exc}") from exc

    # Strip "window.SCREENER_UNIVERSE = " prefix and trailing ";\n".
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise RuntimeError("universe cache malformed: no JSON object found")
    try:
        payload = json.loads(text[start:end + 1])
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"universe cache JSON parse failed: {exc}") from exc

    tickers = payload.get("tickers", [])
    if not tickers:
        raise RuntimeError("universe cache has no tickers")
    return tickers


# --------------------------------------------------------------------------- #
# Task 2: fetch one ticker's OHLCV into a DataFrame.
# --------------------------------------------------------------------------- #
def fetch_ohlcv(session, sym):
    """
    Fetch ~2y of daily candles for one symbol into a pandas DataFrame with
    columns [open, high, low, close, volume], indexed by date.

    Yahoo can interleave nulls for halted/no-trade days; we drop any row whose
    close is null (project canon) so the rolling math never sees gaps.

    Returns the DataFrame, or None if the request fails, the response is
    malformed, or fewer than MIN_ROWS usable rows remain (can't compute SMA200
    / 52-week metrics reliably). Caller retries once before giving up.
    """
    try:
        resp = session.get(
            CHART_URL.format(sym=sym),
            params={"range": "2y", "interval": "1d"},
            timeout=15,
        )
    except requests.RequestException:
        return None
    if resp.status_code != 200:
        return None
    try:
        result = resp.json()["chart"]["result"]
        if not result:
            return None
        r0 = result[0]
        ts = r0["timestamp"]
        q = r0["indicators"]["quote"][0]
    except (ValueError, KeyError, TypeError, IndexError):
        return None

    try:
        df = pd.DataFrame({
            "open": q.get("open"),
            "high": q.get("high"),
            "low": q.get("low"),
            "close": q.get("close"),
            "volume": q.get("volume"),
        }, index=pd.to_datetime(ts, unit="s"))
    except (ValueError, TypeError):
        return None

    # Drop rows with a null close - they break rolling means and returns.
    df = df[df["close"].notna()]
    if len(df) < MIN_ROWS:
        return None
    return df


# --------------------------------------------------------------------------- #
# Task 3: per-ticker metric computation (pure - DataFrame in, dict out).
# --------------------------------------------------------------------------- #
def _safe_ret(close, n):
    """
    Simple return over n trading days: close[-1]/close[-1-n] - 1.

    Returns None (never 0) when there isn't enough history for the lookback,
    so a missing 6M return on a young name is excluded from RS ranking rather
    than masquerading as a 0% return (the 'v or 0' masking trap, project canon).
    """
    if len(close) <= n:
        return None
    prev = close.iloc[-1 - n]
    if prev is None or prev == 0:
        return None
    return float(close.iloc[-1] / prev - 1.0)


def compute_metrics(df):
    """
    Compute the full metric dict for one ticker from its OHLCV DataFrame.

    All moving averages/returns are read at the LAST closed bar. na-guards
    return None (not 0) wherever a value is undefined, so downstream ranking
    and display can distinguish 'no data' from a real zero.
    """
    close = df["close"]
    last = float(close.iloc[-1])

    # --- Moving averages: full EMA + SMA set at each length (D2-02) -------- #
    # SMA150 added (P2 amendment): Minervini's Trend Template is built on the
    # 150-day SMA (criteria 1, 2, 4). EMA150 included for symmetry/reuse.
    sma = {w: float(close.rolling(w).mean().iloc[-1])
           if len(close) >= w else None
           for w in (10, 20, 50, 100, 150, 200)}
    ema = {w: float(close.ewm(span=w, adjust=False).mean().iloc[-1])
           for w in (10, 20, 50, 100, 150, 200)}

    # --- ATR(14): mean true range over 14 bars ---------------------------- #
    prev_close = close.shift(1)
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)
    atr14 = (float(tr.rolling(ATR_WIN).mean().iloc[-1])
             if len(tr) >= ATR_WIN else None)
    # ATR as % of price: the price-neutral form we percentile-rank across the
    # universe into atr_rs (Qullamaggie's "ATR RS >= 50" volatility gate).
    # Cross-sectional rank happens in add_rs_percentiles (P2 amendment).
    atr_pct = (atr14 / last * 100) if (atr14 is not None and last) else None

    # --- 52-week high/low (by close) -------------------------------------- #
    win52 = close.iloc[-WIN_52W:]
    hi52w = float(win52.max())
    lo52w = float(win52.min())
    pct_from_52w_high = (last / hi52w - 1.0) * 100 if hi52w else None   # <=0
    pct_above_52w_low = (last / lo52w - 1.0) * 100 if lo52w else None   # >=0

    # --- 20-day range position: 0 = at 20d low, 1 = at 20d high ----------- #
    win20 = close.iloc[-WIN_20D:]
    hi20, lo20 = float(win20.max()), float(win20.min())
    # na-guard: a flat 20-day band (hi==lo) has no defined position -> None.
    range20_pos = (last - lo20) / (hi20 - lo20) if hi20 != lo20 else None

    # --- Returns over each lookback (None if too young) ------------------- #
    rets = {p: _safe_ret(close, n) for p, n in RET_LOOKBACKS.items()}

    # --- SMA200 rising: compare now vs ~1 month ago ----------------------- #
    sma200_series = close.rolling(200).mean()
    if len(sma200_series.dropna()) > SLOPE_LOOKBACK:
        now200 = sma200_series.iloc[-1]
        past200 = sma200_series.iloc[-1 - SLOPE_LOOKBACK]
        sma200_rising = bool(now200 > past200) if pd.notna(past200) else None
    else:
        sma200_rising = None

    # --- Qullamaggie MA stack: px >= EMA10 >= SMA20 >= SMA50 >= SMA100 >= SMA200
    stack_vals = [last, ema[10], sma[20], sma[50], sma[100], sma[200]]
    ma_stack_ok = (None not in stack_vals
                   and all(stack_vals[i] >= stack_vals[i + 1]
                           for i in range(len(stack_vals) - 1)))

    # --- Green candle on the last closed bar ------------------------------ #
    last_open = float(df["open"].iloc[-1]) if pd.notna(df["open"].iloc[-1]) else None
    prev = float(close.iloc[-2]) if len(close) >= 2 else None
    green_candle = (last_open is not None and prev is not None
                    and last >= prev and last >= last_open)

    return {
        # raw values (D2-03: store both raw and derived)
        "price": round(last, 4),
        "ema10": _r(ema[10]), "ema20": _r(ema[20]), "ema50": _r(ema[50]),
        "ema100": _r(ema[100]), "ema200": _r(ema[200]),
        "sma20": _r(sma[20]), "sma50": _r(sma[50]),
        "sma100": _r(sma[100]), "sma150": _r(sma[150]), "sma200": _r(sma[200]),
        "atr14": _r(atr14), "atr_pct": _r(atr_pct),
        "hi52w": _r(hi52w), "lo52w": _r(lo52w),
        "range20_pos": _r(range20_pos),
        "ret_1w": rets["1w"], "ret_1m": rets["1m"],
        "ret_3m": rets["3m"], "ret_6m": rets["6m"],
        "last_open": _r(last_open),
        # derived booleans/scores
        "pct_from_52w_high": _r(pct_from_52w_high),
        "pct_above_52w_low": _r(pct_above_52w_low),
        "sma200_rising": sma200_rising,
        "ma_stack_ok": ma_stack_ok,
        "green_candle": green_candle,
        # rs_* percentiles filled in by the cross-sectional pass (Task 4)
    }


def _r(v, ndigits=4):
    """Round a float for compact JSON; pass None through untouched."""
    return round(v, ndigits) if isinstance(v, (int, float)) else v


# --------------------------------------------------------------------------- #
# Task 4: universe-wide RS percentiles (cross-sectional - after the loop).
# --------------------------------------------------------------------------- #
def _rank_pct(metrics, src_key, dst_key):
    """
    Percentile-rank one metric across the universe (rank(pct=True)*100, 0-100),
    writing dst_key onto every ticker. Tickers whose src_key is None are
    excluded from the ranking population and get dst_key=None, so missing data
    never distorts everyone else's percentile.
    """
    present = {sym: m[src_key] for sym, m in metrics.items()
               if m.get(src_key) is not None}
    if not present:
        for m in metrics.values():
            m[dst_key] = None
        return
    ranks = (pd.Series(present).rank(pct=True) * 100).round().astype(int)
    for sym, m in metrics.items():
        m[dst_key] = int(ranks[sym]) if sym in ranks.index else None


def add_rs_percentiles(metrics):
    """
    Add rs_1w/1m/3m/6m AND atr_rs to every ticker's metric dict, in place.

    rs_* : each return lookback percentile-ranked WITHIN this universe.
    atr_rs (P2 amendment): atr_pct (ATR as % of price) percentile-ranked across
            the universe -> Qullamaggie's "ATR RS >= 50" volatility gate, i.e.
            above-median volatility vs the pool.

    `metrics` is dict[symbol] -> metric dict.
    """
    for period in RET_LOOKBACKS:                       # "1w","1m","3m","6m"
        _rank_pct(metrics, f"ret_{period}", f"rs_{period}")
    _rank_pct(metrics, "atr_pct", "atr_rs")


# --------------------------------------------------------------------------- #
# Task 5: orchestrate + write cache (D1-06 floor pattern from Phase 1).
# --------------------------------------------------------------------------- #
def write_cache(metrics, path=METRICS_CACHE_PATH):
    """
    Write the metrics cache as a .js wrapper the terminal loads via <script>
    (window.SCREENER_METRICS), mirroring the universe cache format.

    D1-06 floor: if fewer than MIN_VALID_COUNT tickers produced metrics, treat
    it as a failed run - keep the last good file, do NOT overwrite. Log + return
    False so the scheduler sees a soft failure, not a corrupted cache.
    """
    if len(metrics) < MIN_VALID_COUNT:
        print(f"  [skip-write] only {len(metrics)} metric rows "
              f"(< {MIN_VALID_COUNT}) - keeping last good, not overwriting")
        return False

    payload = {
        "generated": datetime.now(GMT8).isoformat(timespec="seconds"),
        "count": len(metrics),
        "metrics": metrics,
    }
    os.makedirs(os.path.dirname(path), exist_ok=True)
    body = "window.SCREENER_METRICS = " + json.dumps(payload, indent=2) + ";\n"
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(body)
    print(f"  [wrote] {len(metrics)} metric rows -> {path}")
    return True


def run_full(dry_run=False, throttle=0.1):
    """
    Full pipeline: handshake -> load universe -> per-ticker fetch+compute
    (drop+log failures, D2-04) -> RS percentile pass -> write cache.

    Returns process exit code: 0 on success (including a logged skip-write),
    1 only on unrecoverable failure (dead handshake / missing universe).
    """
    stamp = datetime.now(GMT8).isoformat(timespec="seconds")
    print(f"=== TX screener metrics build @ {stamp} "
          f"({'DRY' if dry_run else 'LIVE'}) ===")

    try:
        session, _crumb = get_yahoo_session()
    except RuntimeError as exc:
        print(f"[FATAL] handshake failed: {exc}")
        return 1
    try:
        universe = load_universe()
    except RuntimeError as exc:
        print(f"[FATAL] {exc}")
        return 1
    print(f"[stage] universe loaded: {len(universe)}")

    metrics = {}
    dropped_fail = 0
    t0 = time.time()
    for i, row in enumerate(universe, 1):
        sym = row["symbol"]
        df = fetch_ohlcv(session, sym)
        if df is None:
            df = fetch_ohlcv(session, sym)            # one retry (Phase 1 parity)
        if df is None:
            dropped_fail += 1
            print(f"  [drop:fetch-fail] {sym}")
        else:
            metrics[sym] = compute_metrics(df)
        if throttle:
            time.sleep(throttle)

    elapsed = time.time() - t0
    print(f"[stage] metrics computed: {len(metrics)} "
          f"({dropped_fail} fetch-fail) in {elapsed:.1f}s")

    add_rs_percentiles(metrics)
    print(f"[stage] RS percentiles added for {len(metrics)} tickers")

    if dry_run:
        ok = len(metrics) >= MIN_VALID_COUNT
        print(f"[DRY] would write {len(metrics)} metric rows "
              f"({'PASS' if ok else 'BELOW FLOOR'})")
        return 0

    write_cache(metrics)
    print("=== done ===")
    return 0


# --------------------------------------------------------------------------- #
# Task 6: CLI flags + funnel log + scheduler guard.
# --------------------------------------------------------------------------- #
def _load_test():
    """--load-test: prove the universe cache loads, print the count."""
    try:
        universe = load_universe()
    except RuntimeError as exc:
        print(f"[FAIL] {exc}")
        return 1
    print(f"[OK] loaded {len(universe)} universe tickers")
    print("     sample:", ", ".join(r["symbol"] for r in universe[:8]))
    return 0


def _probe(sym):
    """--probe SYM: fetch one ticker, compute its metrics, pretty-print them."""
    try:
        session, _ = get_yahoo_session()
    except RuntimeError as exc:
        print(f"[FAIL] {exc}")
        return 1
    df = fetch_ohlcv(session, sym)
    if df is None:
        print(f"[FAIL] could not fetch usable OHLCV for {sym}")
        return 1
    print(f"[OK] {sym}: {len(df)} rows")
    print(df.tail())
    print("\n[metrics]")
    m = compute_metrics(df)
    for k, v in m.items():
        print(f"  {k:18} {v}")
    return 0


if __name__ == "__main__":
    if "--load-test" in sys.argv:
        sys.exit(_load_test())
    probe_flag = [a for a in sys.argv if a.startswith("--probe")]
    if probe_flag:
        # accept "--probe NVDA" (next arg) or "--probe=NVDA"
        sym = None
        if "=" in probe_flag[0]:
            sym = probe_flag[0].split("=", 1)[1]
        else:
            idx = sys.argv.index(probe_flag[0])
            if idx + 1 < len(sys.argv):
                sym = sys.argv[idx + 1]
        if not sym:
            print("[FAIL] --probe needs a symbol, e.g. --probe NVDA")
            sys.exit(1)
        sys.exit(_probe(sym.upper()))
    if "--dry-run" in sys.argv:
        sys.exit(run_full(dry_run=True))
    # Default: full live run (handshake -> load -> compute -> RS -> write).
    try:
        sys.exit(run_full(dry_run=False))
    except Exception as exc:  # last-resort guard - never crash the scheduler
        print(f"[FATAL] unrecoverable: {exc}")
        sys.exit(1)
