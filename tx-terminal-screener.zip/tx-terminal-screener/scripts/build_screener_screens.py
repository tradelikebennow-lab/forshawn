#!/usr/bin/env python3
"""
TX Terminal v2 - Methodology Screener: Screen Filters (Phase 3)
==============================================================
Reads the Phase 2 metrics cache and produces TWO ranked watchlists by applying
each methodology's published criteria:

  - Qullamaggie  : momentum-leader watchlist (RS + full MA stack + volatility +
                   upper-half 20-day range)
  - Minervini    : trend-confirmation watchlist (8-criteria Trend Template +
                   green candle + >=$1B mcap)

Both are WATCHLISTS, not buy signals - the breakout/entry is a separate chart
judgment (out of scope, per PROJECT.md).

PURE LOGIC. No network, no Yahoo handshake - it reads data/tx-screener-metrics.js
(already computed nightly by update_screener_metrics.py) and writes
data/tx-screener-screens.js (window.SCREENER_SCREENS = {...}). Runs in <1s.

Phase 3 decisions (locked):
  D3-01  thresholds applied LITERALLY (Qulla RS>=97, Minervini RS>=70), counts
         logged prominently - we tune AFTER seeing real output, not before.
  D3-02  Qullamaggie RS gate is any-period: max(rs_1w,rs_1m,rs_3m,rs_6m) >= 97.
  D3-03  rank each list by its RS desc, dollar-volume as tiebreak.
  D3-04  Minervini "RS rating" = rs_6m, fallback rs_3m (closest to IBD's long
         window); if both None -> criterion 8 fails.
  D3-05  fail-closed: any missing required field excludes the ticker from that
         screen; per-name reason trail stored for audit + the terminal's "why".
"""

import sys
import os
import json
from datetime import datetime, timezone, timedelta

# Paths: this file lives in scripts/, caches live in ../data/ (project layout).
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
METRICS_CACHE_PATH = os.path.normpath(
    os.path.join(_SCRIPT_DIR, "..", "data", "tx-screener-metrics.js")
)
UNIVERSE_CACHE_PATH = os.path.normpath(
    os.path.join(_SCRIPT_DIR, "..", "data", "tx-screener-universe.js")
)
SCREENS_CACHE_PATH = os.path.normpath(
    os.path.join(_SCRIPT_DIR, "..", "data", "tx-screener-screens.js")
)
GMT8 = timezone(timedelta(hours=8))   # project canon: GMT+8, no DST

# Thresholds (D3-01: literal published values; tune later from real counts).
QULLA_RS = 97          # RS percentile on ANY of 1W/1M/3M/6M
QULLA_ATR_RS = 50      # above-median volatility vs the universe
QULLA_RANGE = 0.5      # last close in the upper half of its 20-day range
MINERV_RS = 70         # Minervini Trend Template criterion 8
MCAP_FLOOR = 1_000_000_000


def _load_js_cache(path, var_label):
    """
    Read a `window.X = {json};` cache file and return the parsed dict.
    Strips the JS assignment wrapper, then json.loads the object. Raises
    RuntimeError on missing/malformed file (caller decides what to do).
    """
    if not os.path.exists(path):
        raise RuntimeError(f"{var_label} cache not found at {path}")
    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise RuntimeError(f"{var_label} cache malformed: no JSON object")
    try:
        return json.loads(text[start:end + 1])
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"{var_label} JSON parse failed: {exc}") from exc


def load_metrics(path=METRICS_CACHE_PATH):
    """Return dict[symbol] -> metric dict from the Phase 2 metrics cache."""
    payload = _load_js_cache(path, "metrics")
    metrics = payload.get("metrics", {})
    if not metrics:
        raise RuntimeError("metrics cache has no 'metrics' object")
    return metrics


def load_universe_mcap(path=UNIVERSE_CACHE_PATH):
    """
    Map symbol -> {mcap, dollar_vol} from the universe cache. The metrics cache
    doesn't carry mcap/$vol, so we pull them here for the mcap gate (both
    screens) and the dollar-volume ranking tiebreak (D3-03).
    """
    try:
        payload = _load_js_cache(path, "universe")
    except RuntimeError:
        return {}
    out = {}
    for t in payload.get("tickers", []):
        out[t["symbol"]] = {"mcap": t.get("mcap"),
                            "dollar_vol": t.get("dollar_vol")}
    return out


# --------------------------------------------------------------------------- #
# Task 2: Qullamaggie screen.
# --------------------------------------------------------------------------- #
def qualifies_qulla(m, mcap):
    """
    Apply the 5 Qullamaggie momentum-leader criteria to one metric dict.
    Returns (passed: bool, fails: list[str]). Fail-closed: a missing required
    field is itself a failure (recorded), never a silent pass.
    """
    fails = []

    # 1. RS >= 97 on ANY of 1W/1M/3M/6M (D3-02). Ignore None periods.
    rs_vals = [m.get(f"rs_{p}") for p in ("1w", "1m", "3m", "6m")]
    rs_present = [v for v in rs_vals if v is not None]
    if not rs_present:
        fails.append("rs:no-data")
    elif max(rs_present) < QULLA_RS:
        fails.append(f"rs:max{max(rs_present)}<{QULLA_RS}")

    # 2. Full MA stack: px >= EMA10 >= SMA20 >= SMA50 >= SMA100 >= SMA200.
    if m.get("ma_stack_ok") is not True:
        fails.append("ma_stack:fail")

    # 3. ATR RS >= 50 (above-median volatility vs the universe).
    atr_rs = m.get("atr_rs")
    if atr_rs is None:
        fails.append("atr_rs:no-data")
    elif atr_rs < QULLA_ATR_RS:
        fails.append(f"atr_rs:{atr_rs}<{QULLA_ATR_RS}")

    # 4. Price in upper half of its 20-day range.
    rng = m.get("range20_pos")
    if rng is None:
        fails.append("range20:no-data")
    elif rng < QULLA_RANGE:
        fails.append(f"range20:{rng:.2f}<{QULLA_RANGE}")

    # 5. Market cap >= $1B.
    if mcap is None or mcap < MCAP_FLOOR:
        fails.append("mcap:<1B")

    return (len(fails) == 0, fails)


# --------------------------------------------------------------------------- #
# Task 3: Minervini Trend Template screen.
# --------------------------------------------------------------------------- #
def qualifies_minervini(m, mcap):
    """
    Apply Minervini's 8-criteria Trend Template + green candle + mcap.
    Returns (passed, fails). Fail-closed on any missing required field.

    Field map:
      px=price, sma50/sma150/sma200, sma200_rising, pct_above_52w_low,
      pct_from_52w_high, RS-rating = rs_6m else rs_3m (D3-04), green_candle.
    """
    fails = []
    px = m.get("price")
    s50, s150, s200 = m.get("sma50"), m.get("sma150"), m.get("sma200")

    # Guard the core MAs up front - several criteria depend on them.
    if None in (px, s50, s150, s200):
        fails.append("ma:no-data")

    if None not in (px, s150, s200):
        # 1. px > SMA150 and px > SMA200
        if not (px > s150 and px > s200):
            fails.append("c1:px>sma150&200")
        # 2. SMA150 > SMA200
        if not (s150 > s200):
            fails.append("c2:sma150>sma200")
    # 3. SMA200 trending up (>= ~1 month)
    if m.get("sma200_rising") is not True:
        fails.append("c3:sma200-rising")
    if None not in (s50, s150, s200):
        # 4. SMA50 > SMA150 and > SMA200
        if not (s50 > s150 and s50 > s200):
            fails.append("c4:sma50>sma150&200")
    if None not in (px, s50):
        # 5. px > SMA50
        if not (px > s50):
            fails.append("c5:px>sma50")

    # 6. px >= 25% above 52-week low
    pal = m.get("pct_above_52w_low")
    if pal is None:
        fails.append("c6:no-data")
    elif pal < 25:
        fails.append(f"c6:{pal:.0f}%<25%above-low")

    # 7. px within 25% of 52-week high (pct_from_high is <=0, so >= -25)
    pfh = m.get("pct_from_52w_high")
    if pfh is None:
        fails.append("c7:no-data")
    elif pfh < -25:
        fails.append(f"c7:{pfh:.0f}%<-25%from-high")

    # 8. RS rating >= 70 (D3-04: rs_6m, fallback rs_3m).
    rs_rating = m.get("rs_6m")
    if rs_rating is None:
        rs_rating = m.get("rs_3m")
    if rs_rating is None:
        fails.append("c8:rs-no-data")
    elif rs_rating < MINERV_RS:
        fails.append(f"c8:rs{rs_rating}<{MINERV_RS}")

    # + green candle on last closed bar
    if m.get("green_candle") is not True:
        fails.append("green:fail")

    # + market cap >= $1B
    if mcap is None or mcap < MCAP_FLOOR:
        fails.append("mcap:<1B")

    return (len(fails) == 0, fails)


# --------------------------------------------------------------------------- #
# Task 4: run both screens, rank, near-miss, assemble + write.
# --------------------------------------------------------------------------- #
def _qulla_sort_key(sym, m, uni):
    """Qulla rank key: its max-RS desc, dollar-volume tiebreak (D3-03)."""
    rs_vals = [m.get(f"rs_{p}") for p in ("1w", "1m", "3m", "6m")]
    rs_present = [v for v in rs_vals if v is not None]
    max_rs = max(rs_present) if rs_present else -1
    dv = (uni.get(sym) or {}).get("dollar_vol") or 0
    return (-max_rs, -dv)


def _minerv_sort_key(sym, m, uni):
    """Minervini rank key: RS-rating desc, dollar-volume tiebreak (D3-03)."""
    rs_rating = m.get("rs_6m")
    if rs_rating is None:
        rs_rating = m.get("rs_3m")
    rs_rating = rs_rating if rs_rating is not None else -1
    dv = (uni.get(sym) or {}).get("dollar_vol") or 0
    return (-rs_rating, -dv)


def _row(sym, m, uni):
    """Compact display row for a passing ticker (raw + key derived metrics)."""
    rs_vals = [m.get(f"rs_{p}") for p in ("1w", "1m", "3m", "6m")]
    rs_present = [v for v in rs_vals if v is not None]
    u = uni.get(sym) or {}
    return {
        "symbol": sym,
        "price": m.get("price"),
        "max_rs": max(rs_present) if rs_present else None,
        "rs_3m": m.get("rs_3m"), "rs_6m": m.get("rs_6m"),
        "atr_rs": m.get("atr_rs"),
        "range20_pos": m.get("range20_pos"),
        "pct_from_52w_high": m.get("pct_from_52w_high"),
        "pct_above_52w_low": m.get("pct_above_52w_low"),
        "mcap": u.get("mcap"), "dollar_vol": u.get("dollar_vol"),
        # Phase 4.1: passthrough for the UI action-state classifier (no logic here).
        "atr14": m.get("atr14"), "sma50": m.get("sma50"),
        "ema10": m.get("ema10"), "ema20": m.get("ema20"),
        "sma200_rising": m.get("sma200_rising"), "green_candle": m.get("green_candle"),
    }


def build_screens(metrics, uni):
    """
    Run both screens over every ticker. Returns a dict with, per screen,
    the ranked pass-list, the near-miss list (failed exactly 1 criterion,
    for tuning visibility), and counts.
    """
    qulla_pass, qulla_near = [], []
    minerv_pass, minerv_near = [], []

    for sym, m in metrics.items():
        mcap = (uni.get(sym) or {}).get("mcap")

        q_ok, q_fails = qualifies_qulla(m, mcap)
        if q_ok:
            qulla_pass.append(sym)
        elif len(q_fails) == 1:
            qulla_near.append({"symbol": sym, "missing": q_fails[0]})

        mn_ok, mn_fails = qualifies_minervini(m, mcap)
        if mn_ok:
            minerv_pass.append(sym)
        elif len(mn_fails) == 1:
            minerv_near.append({"symbol": sym, "missing": mn_fails[0]})

    qulla_pass.sort(key=lambda s: _qulla_sort_key(s, metrics[s], uni))
    minerv_pass.sort(key=lambda s: _minerv_sort_key(s, metrics[s], uni))

    return {
        "qullamaggie": {
            "count": len(qulla_pass),
            "passed": [dict(rank=i + 1, **_row(s, metrics[s], uni))
                       for i, s in enumerate(qulla_pass)],
            "near_miss": qulla_near,
        },
        "minervini": {
            "count": len(minerv_pass),
            "passed": [dict(rank=i + 1, **_row(s, metrics[s], uni))
                       for i, s in enumerate(minerv_pass)],
            "near_miss": minerv_near,
        },
    }


def write_cache(screens, universe_count, path=SCREENS_CACHE_PATH):
    """
    Write the screens cache (window.SCREENER_SCREENS). Unlike the universe/
    metrics caches there is NO min-count floor: a screen legitimately can
    return few or zero names on a given day, and that is real signal, not a
    failed run (D3-01). We always write and log the counts.
    """
    payload = {
        "generated": datetime.now(GMT8).isoformat(timespec="seconds"),
        "universe_count": universe_count,
        "thresholds": {"qulla_rs": QULLA_RS, "qulla_atr_rs": QULLA_ATR_RS,
                       "qulla_range": QULLA_RANGE, "minerv_rs": MINERV_RS},
        "screens": screens,
    }
    os.makedirs(os.path.dirname(path), exist_ok=True)
    body = "window.SCREENER_SCREENS = " + json.dumps(payload, indent=2) + ";\n"
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(body)
    print(f"  [wrote] screens -> {path}")


def run_full(dry_run=False):
    """Load -> screen -> rank -> (write). Logs the pass-counts prominently."""
    stamp = datetime.now(GMT8).isoformat(timespec="seconds")
    print(f"=== TX screener screens build @ {stamp} "
          f"({'DRY' if dry_run else 'LIVE'}) ===")
    try:
        metrics = load_metrics()
    except RuntimeError as exc:
        print(f"[FATAL] {exc}")
        return 1
    uni = load_universe_mcap()
    print(f"[stage] metrics loaded: {len(metrics)}")

    screens = build_screens(metrics, uni)
    q, mn = screens["qullamaggie"], screens["minervini"]
    print(f"[RESULT] Qullamaggie: {q['count']} passed "
          f"({len(q['near_miss'])} near-miss)")
    print(f"[RESULT] Minervini:   {mn['count']} passed "
          f"({len(mn['near_miss'])} near-miss)")
    if q["passed"]:
        print("  Qulla top 5:", ", ".join(
            f"{r['symbol']}(rs{r['max_rs']})" for r in q["passed"][:5]))
    if mn["passed"]:
        print("  Minervini top 5:", ", ".join(
            f"{r['symbol']}(rs{r['rs_6m'] if r['rs_6m'] is not None else r['rs_3m']})"
            for r in mn["passed"][:5]))

    if dry_run:
        print("[DRY] no write")
        return 0
    write_cache(screens, len(metrics))
    print("=== done ===")
    return 0


# --------------------------------------------------------------------------- #
# Task 5: CLI.
# --------------------------------------------------------------------------- #
def _load_test():
    try:
        metrics = load_metrics()
    except RuntimeError as exc:
        print(f"[FAIL] {exc}")
        return 1
    print(f"[OK] loaded {len(metrics)} metrics")
    print("     sample:", ", ".join(list(metrics)[:8]))
    return 0


def _explain(sym):
    """Print, criterion by criterion, why SYM passes/fails each screen."""
    try:
        metrics = load_metrics()
    except RuntimeError as exc:
        print(f"[FAIL] {exc}")
        return 1
    m = metrics.get(sym)
    if m is None:
        print(f"[FAIL] {sym} not in metrics universe")
        return 1
    uni = load_universe_mcap()
    mcap = (uni.get(sym) or {}).get("mcap")
    q_ok, q_fails = qualifies_qulla(m, mcap)
    mn_ok, mn_fails = qualifies_minervini(m, mcap)
    print(f"=== {sym} @ ${m.get('price')} | mcap "
          f"{('$%.1fB' % (mcap/1e9)) if mcap else 'n/a'} ===")
    print(f"\nQullamaggie: {'PASS' if q_ok else 'FAIL'}")
    print("  rs:", {p: m.get(f'rs_{p}') for p in ('1w','1m','3m','6m')},
          "| atr_rs:", m.get("atr_rs"), "| range20:", m.get("range20_pos"),
          "| ma_stack:", m.get("ma_stack_ok"))
    if q_fails:
        print("  fails:", q_fails)
    print(f"\nMinervini: {'PASS' if mn_ok else 'FAIL'}")
    print("  px/sma50/150/200:", m.get("price"), m.get("sma50"),
          m.get("sma150"), m.get("sma200"))
    print("  sma200_rising:", m.get("sma200_rising"),
          "| %above_low:", m.get("pct_above_52w_low"),
          "| %from_high:", m.get("pct_from_52w_high"),
          "| rs6m:", m.get("rs_6m"), "| green:", m.get("green_candle"))
    if mn_fails:
        print("  fails:", mn_fails)
    return 0


if __name__ == "__main__":
    if "--load-test" in sys.argv:
        sys.exit(_load_test())
    exp = [a for a in sys.argv if a.startswith("--explain")]
    if exp:
        sym = None
        if "=" in exp[0]:
            sym = exp[0].split("=", 1)[1]
        else:
            idx = sys.argv.index(exp[0])
            if idx + 1 < len(sys.argv):
                sym = sys.argv[idx + 1]
        if not sym:
            print("[FAIL] --explain needs a symbol, e.g. --explain NVDA")
            sys.exit(1)
        sys.exit(_ex