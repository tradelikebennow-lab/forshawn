/* SAMPLE DATA — fake rows so terminal.html renders without running the pipeline.
   To use: copy to tx-screener-screens.js (and stub the other two caches), or just
   run the real scripts. Do NOT mistake these numbers for real market data. */
window.SCREENER_SCREENS = {
  "generated": "2026-01-01T12:00:00+08:00",
  "universe_count": 3,
  "thresholds": { "qulla_rs": 97, "qulla_atr_rs": 50, "qulla_range": 0.5, "minerv_rs": 70 },
  "screens": {
    "qullamaggie": {
      "count": 2,
      "passed": [
        {"rank":1,"symbol":"AAAA","price":100.00,"max_rs":99,"rs_3m":98,"rs_6m":99,"atr_rs":80,"range20_pos":0.9,
         "pct_from_52w_high":-2.0,"pct_above_52w_low":120.0,"mcap":50000000000,"dollar_vol":1500000000,
         "atr14":3.0,"sma50":80.0,"ema10":97.0,"ema20":94.0,"sma200_rising":true,"green_candle":true},
        {"rank":2,"symbol":"BBBB","price":40.00,"max_rs":97,"rs_3m":96,"rs_6m":90,"atr_rs":65,"range20_pos":0.7,
         "pct_from_52w_high":-6.0,"pct_above_52w_low":85.0,"mcap":8000000000,"dollar_vol":400000000,
         "atr14":2.0,"sma50":38.0,"ema10":41.0,"ema20":42.0,"sma200_rising":true,"green_candle":false}
      ],
      "near_miss": [ {"symbol":"CCCC","missing":"range20:0.41<0.5"} ]
    },
    "minervini": {
      "count": 1,
      "passed": [
        {"rank":1,"symbol":"DDDD","price":250.00,"max_rs":85,"rs_3m":80,"rs_6m":88,"atr_rs":40,"range20_pos":0.6,
         "pct_from_52w_high":-3.0,"pct_above_52w_low":45.0,"mcap":400000000000,"dollar_vol":1200000000,
         "atr14":5.0,"sma50":245.0,"ema10":250.0,"ema20":248.0,"sma200_rising":true,"green_candle":true}
      ],
      "near_miss": [ {"symbol":"EEEE","missing":"c7:-31%<-25%from-high"} ]
    }
  }
};
