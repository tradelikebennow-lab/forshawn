@echo off
REM ============================================================
REM  TX Terminal launcher
REM  Serves the project folder over http://localhost so the
REM  browser will load the data\*.js caches (file:// blocks them).
REM  Double-click this file to open the screener.
REM ============================================================

REM Run from the folder this .bat lives in (the project root).
cd /d "%~dp0"

REM Pick a port unlikely to clash.
set PORT=8765

REM Open the browser first (server start is near-instant; page retries fonts/data on load).
start "" "http://localhost:%PORT%/terminal.html"

REM Start the static server in this window. Close the window (or Ctrl+C) to stop it.
echo.
echo  TX Terminal serving at http://localhost:%PORT%/terminal.html
echo  Leave this window open while you use the terminal.
echo  Close it (or press Ctrl+C) when you're done.
echo.
python -m http.server %PORT%
