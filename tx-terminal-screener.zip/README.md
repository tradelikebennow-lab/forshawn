# TX Terminal — Methodology Screener

A nightly stock-screening tool that ranks a liquid US equity universe against two
rule-based screens — a **Momentum Screen** and a **Trend Screen** — and renders the
resulting watchlists in a self-contained desktop terminal UI.

> **It is a watchlist generator, not a trading bot.** It surfaces names that *qualify*
> under each screen. It does **not** generate entries, exits, or breakout signals —
> that is a separate human chart-reading step and is intentionally out of scope.

📖 **Full technical brief: open [`HANDOFF.html`](HANDOFF.html) in a browser.**
It documents the architecture, every metric formula, both screen definitions, the
cache data contracts, locked design decisions, and known gotchas.

---

## How it works (60 seconds)

```
1. Universe   (weekly)  →  pick ~482 liquid US names      → data/tx-screener-universe.js
2. Metrics    (nightly) →  compute MAs, ATR, RS, 52w, …   → data/tx-screener-metrics.js
3. Screens    (nightly) →  apply the two screens          → data/tx-screener-screens.js
4. Terminal UI          →  reads the screens cache, renders   (terminal.html)
```

Three Python scripts write three JavaScript cache files. A static HTML page reads
them and draws the screener. No server-side anything, no framework, no build step,
no paid APIs.

## Layout

```
.
├── terminal.html              # the screener UI
├── start_terminal.bat         # double-click: serve over http + open browser
├── HANDOFF.html               # full developer brief — READ THIS FIRST
├── requirements.txt
├── scripts/
│   ├── update_screener_universe.py   # weekly
│   ├── update_screener_metrics.py    # nightly (~75s)
│   └── build_screener_screens.py     # nightly (<1s)
└── data/                      # generated caches (gitignored) + SAMPLE_screens.js
```

## Quick start

```bash
# 1. install deps (Windows shown; venv recommended)
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt

# 2. generate the caches, IN ORDER
.venv\Scripts\python.exe scripts\update_screener_universe.py
.venv\Scripts\python.exe scripts\update_screener_metrics.py
.venv\Scripts\python.exe scripts\build_screener_screens.py

# 3. open the UI (must be over http:// — see note below)
start_terminal.bat
```

To preview the UI **without** running the pipeline, copy `data/SAMPLE_screens.js`
to `data/tx-screener-screens.js` (fake data) and open via the server.

## Important notes

- **Serve over `http://`, not `file://`.** Chrome blocks a `file://` page from loading
  local `.js` caches, so the UI shows "no data." `start_terminal.bat` runs a local
  static server to avoid this.
- **Run scripts in order** (universe → metrics → screens); each reads the previous one's cache.
- **`null` means "no data", `0` means zero** — enforced through the whole pipeline.
- **Caches are generated, not committed.** `data/*.js` is gitignored; regenerate locally.
- Timestamps are **GMT+8** throughout (no DST).

## Stack

Python 3 (pandas, numpy, requests) · vanilla HTML/CSS/JS. Data source: Yahoo Finance
public endpoints (no API key).
